# HCI-CommandCenter

## First Stage: Find what is in place
* kinect interface: Wisc-HCI/ConfusionDetectTask/interface.py

## Second Stage: Implement each terminal
* kinect
* ROS
* eye-tracker
* ...

## Third Stage: GUI
